
#include <stdarg.h>
#include <stddef.h>
#include <limits.h>

#include "ucos_ii.h"
#include "openmips.h"
